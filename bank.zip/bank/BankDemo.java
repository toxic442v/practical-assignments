import java.util.ArrayList;
import java.util.List;

public class BankDemo {
    public static void main(String[] args) {
        List<Account> accounts = new ArrayList<>();
        accounts.add(new SavingsAccount("SAV-001", 1000.00, 200.00));
        accounts.add(new CurrentAccount("CUR-001", 300.00, 500.00));
        accounts.add(new SavingsAccount("SAV-002", 500.00, 100.00));
        accounts.add(new CurrentAccount("CUR-002", 800.00, 250.00));

        System.out.println("=== Round 1: withdraw 400 from every account (via Account reference) ===");
        for (Account a : accounts) {
            a.withdraw(400.00);
        }

        System.out.println("\n=== Round 2: withdraw 600 from every account ===");
        for (Account a : accounts) {
            a.withdraw(600.00);
        }

        System.out.println("\n=== End of month processing ===");
        for (Account a : accounts) {
            a.endOfMonth();
        }

        System.out.println("\n=== Final balances ===");
        for (Account a : accounts) {
            System.out.printf("  %s: %.2f%n", a.getAccountNumber(), a.getBalance());
        }
    }
}
